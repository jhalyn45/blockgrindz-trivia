import React, { useEffect, useState } from "react";

function App() {
  return (
    <div className="p-4">
      <h1 className="text-xl font-bold">BlockGrindz Trivia Game</h1>
      <p>Insert TriviaEngine and Leaderboard components here.</p>
    </div>
  );
}

export default App;
